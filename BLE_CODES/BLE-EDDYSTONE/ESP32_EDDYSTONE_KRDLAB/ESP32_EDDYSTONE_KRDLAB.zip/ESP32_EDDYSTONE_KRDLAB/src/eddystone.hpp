// Copyright (c) 2019 Sho Kuroda <krdlab@gmail.com>
// 
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

#ifndef EDDYSTONE_HPP_
#define EDDYSTONE_HPP_

#include "eddystone/uid.hpp"
// TODO: other formats

#endif
