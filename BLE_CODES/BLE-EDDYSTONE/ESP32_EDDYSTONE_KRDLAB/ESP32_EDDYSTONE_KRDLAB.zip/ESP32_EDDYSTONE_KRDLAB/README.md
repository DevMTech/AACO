[Eddystone specification](https://github.com/google/eddystone)
