Readme.txt

The included files are code to accompany the article -

"Build an Arduino Multi-Node BLE Humidity and Temperature Sensor Monitor".
 *****************************************************
 ** This software is offered strictly as is with no **
 ** warranties whatsoever. Use it at your own risk. **
 *****************************************************

SolarBeaconSannerA.ino - Scanner with output to the serial monitor
SolarBeaconSannerB.ino - Scanner with output to the serial monitor and LCD
SolarBeaconSannerC.ino - Scanner with output to the LCD

