# esp-arduino-apboot
ESP8266 wifi configurator in Arduino lang.. uses eeprom for configs, boots to AP mode if no working config found
