#ifndef SSID_H_
#define SSID_H_

//const char* ssid  = "cdac";       const char* password  = "";

RTC_DATA_ATTR char* ssid  = "cdac";   RTC_DATA_ATTR char* password = "";


#endif
